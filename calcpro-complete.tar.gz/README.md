# CalcPro - Advanced File Manager

تطبيق إدارة ملفات متقدم مخفي خلف واجهة حاسبة. يوفر تخزين آمن للصور، الفيديوهات، والمستندات مع إمكانية الوصول عبر رمز PIN فريد.

## المميزات

- 🔐 **نظام أمان متقدم** - رمز PIN فريد لكل مستخدم
- 📱 **واجهة حاسبة** - مموه تماماً كحاسبة عادية
- 📁 **إدارة ملفات شاملة** - دعم للصور، فيديوهات، ومستندات
- 🌐 **تخزين هجين** - يعمل أونلاين وأوفلاين
- 🎨 **تصميم متجاوب** - يعمل على جميع الأجهزة
- 🌙 **وضع ليلي** - تبديل بين الأوضاع الفاتح والداكن

## التشغيل

### المتطلبات
- Node.js 18+
- PostgreSQL database

### التثبيت
```bash
npm install
npm run dev
```

### متغيرات البيئة
```env
DATABASE_URL=your_postgresql_connection_string
SESSION_SECRET=your_session_secret_key
```

## النشر على Vercel

1. ادفع الكود إلى GitHub repository
2. اربط Repository بـ Vercel
3. أضف متغيرات البيئة في إعدادات Vercel
4. انشر التطبيق!

## الاستخدام

1. افتح التطبيق - ستظهر واجهة حاسبة عادية
2. أدخل رمز PIN مكون من 4 أرقام
3. اضغط "=" للدخول لمدير الملفات
4. ارفع واعرض ملفاتك بشكل آمن

## التكنولوجيا المستخدمة

- **Frontend:** React + TypeScript + Tailwind CSS
- **Backend:** Express.js + PostgreSQL
- **ORM:** Drizzle ORM
- **Authentication:** Session-based with PIN system
- **Storage:** Hybrid (Local + Database)

---

© 2024 CalcPro - Advanced File Management Solution