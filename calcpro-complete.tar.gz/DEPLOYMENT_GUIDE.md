# دليل النشر الدائم لتطبيق CalcPro

## خطوات النشر المجاني على Vercel

### 1. إنشاء حساب GitHub (مجاني)
- اذهب إلى [GitHub.com](https://github.com)
- اضغط "Sign up" وأنشئ حساب جديد
- تأكد من تأكيد الإيميل

### 2. إنشاء حساب Vercel (مجاني)
- اذهب إلى [Vercel.com](https://vercel.com)
- اضغط "Sign up" 
- اختر "Continue with GitHub" للربط المباشر

### 3. رفع التطبيق لـ GitHub
```bash
# إنشاء repository جديد في GitHub باسم "calcpro-app"
# ثم في terminal:
git init
git add .
git commit -m "Initial CalcPro deployment"
git remote add origin https://github.com/username/calcpro-app.git
git push -u origin main
```

### 4. ربط المشروع بـ Vercel
1. في Vercel Dashboard، اضغط "New Project"
2. اختر repository "calcpro-app" من GitHub
3. اضغط "Import"

### 5. إعداد متغيرات البيئة
في إعدادات Vercel، أضف:
```
DATABASE_URL = postgres://your-vercel-postgres-url
SESSION_SECRET = your-secure-secret-key-123456789
NODE_ENV = production
```

### 6. إعداد قاعدة البيانات
1. في Vercel Dashboard → Storage → Create Database
2. اختر "Postgres" (مجاني حتى 60 ساعة/شهر)
3. انسخ رابط DATABASE_URL وأضفه للمتغيرات

### 7. النشر النهائي
- Vercel سينشر التطبيق تلقائياً
- ستحصل على رابط مثل: `https://calcpro-app.vercel.app`

## ميزات النشر المجاني:
✅ رابط دائم يعمل 24/7
✅ تحديثات تلقائية عند تعديل الكود  
✅ قاعدة بيانات مجانية
✅ شهادة SSL مجانية
✅ نسخ احتياطية في GitHub

## ملاحظات مهمة:
- الخدمة مجانية للاستخدام الشخصي
- قاعدة البيانات المجانية تكفي لآلاف الملفات
- يمكن ترقية الخطة لاحقاً عند الحاجة

## المساعدة:
إذا واجهت أي مشكلة، تواصل معي وسأساعدك خطوة بخطوة!