import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  pin: text("pin").notNull(),
  securityQuestion: text("security_question"),
  securityAnswer: text("security_answer"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'image', 'video', 'document'
  size: integer("size").notNull(),
  mimeType: text("mime_type").notNull(),
  data: text("data").notNull(), // base64 encoded file data
  createdAt: timestamp("created_at").defaultNow(),
});

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  theme: text("theme").notNull().default("light"), // 'light' or 'dark'
  language: text("language").notNull().default("en"), // 'en' or 'ar'
  isPremium: boolean("is_premium").notNull().default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  pin: true,
  securityQuestion: true,
  securityAnswer: true,
});

export const insertFileSchema = createInsertSchema(files).pick({
  userId: true,
  name: true,
  type: true,
  size: true,
  mimeType: true,
  data: true,
});

export const insertSettingsSchema = createInsertSchema(settings).pick({
  userId: true,
  theme: true,
  language: true,
  isPremium: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type File = typeof files.$inferSelect;
export type InsertFile = z.infer<typeof insertFileSchema>;
export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
