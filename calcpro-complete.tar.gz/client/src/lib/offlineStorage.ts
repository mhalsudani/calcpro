// Offline storage management using IndexedDB
import type { File as FileType, User, Settings } from "@shared/schema";

const DB_NAME = "CalcProDB";
const DB_VERSION = 1;

interface OfflineFile extends Omit<FileType, 'id' | 'userId'> {
  localId: string;
  userId: number;
  serverId?: number;
  syncStatus: 'synced' | 'pending' | 'local-only';
  lastModified: Date;
}

interface OfflineUser extends Omit<User, 'id'> {
  localId: string;
  serverId?: number;
  syncStatus: 'synced' | 'pending' | 'local-only';
}

class OfflineStorage {
  private db: IDBDatabase | null = null;

  async initDB(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };
      
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        // Users store
        if (!db.objectStoreNames.contains('users')) {
          const userStore = db.createObjectStore('users', { keyPath: 'localId' });
          userStore.createIndex('pin', 'pin', { unique: true });
          userStore.createIndex('serverId', 'serverId', { unique: false });
        }
        
        // Files store
        if (!db.objectStoreNames.contains('files')) {
          const fileStore = db.createObjectStore('files', { keyPath: 'localId' });
          fileStore.createIndex('userId', 'userId', { unique: false });
          fileStore.createIndex('type', 'type', { unique: false });
          fileStore.createIndex('syncStatus', 'syncStatus', { unique: false });
        }
        
        // Settings store
        if (!db.objectStoreNames.contains('settings')) {
          const settingsStore = db.createObjectStore('settings', { keyPath: 'userId' });
        }
      };
    });
  }

  // User operations
  async createUser(userData: { pin: string }): Promise<OfflineUser> {
    const user: OfflineUser = {
      localId: this.generateId(),
      pin: userData.pin,
      syncStatus: 'local-only',
      createdAt: new Date(),
    };
    
    return this.saveToStore('users', user);
  }

  async getUserByPin(pin: string): Promise<OfflineUser | null> {
    if (!this.db) await this.initDB();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['users'], 'readonly');
      const store = transaction.objectStore('users');
      const index = store.index('pin');
      const request = index.get(pin);
      
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  // File operations
  async createFile(fileData: {
    name: string;
    type: string;
    size: number;
    mimeType: string;
    data: string;
    userId: number;
  }): Promise<OfflineFile> {
    const file: OfflineFile = {
      localId: this.generateId(),
      ...fileData,
      syncStatus: 'local-only',
      lastModified: new Date(),
      createdAt: new Date(),
    };
    
    return this.saveToStore('files', file);
  }

  async getFilesByUserId(userId: number): Promise<OfflineFile[]> {
    if (!this.db) await this.initDB();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['files'], 'readonly');
      const store = transaction.objectStore('files');
      const index = store.index('userId');
      const request = index.getAll(userId);
      
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  async deleteFile(localId: string): Promise<boolean> {
    if (!this.db) await this.initDB();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['files'], 'readwrite');
      const store = transaction.objectStore('files');
      const request = store.delete(localId);
      
      request.onsuccess = () => resolve(true);
      request.onerror = () => reject(request.error);
    });
  }

  // Sync operations
  async getUnsyncedFiles(): Promise<OfflineFile[]> {
    if (!this.db) await this.initDB();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['files'], 'readonly');
      const store = transaction.objectStore('files');
      const index = store.index('syncStatus');
      const request = index.getAll('local-only');
      
      request.onsuccess = () => {
        const localOnly = request.result || [];
        const pendingRequest = index.getAll('pending');
        
        pendingRequest.onsuccess = () => {
          const pending = pendingRequest.result || [];
          resolve([...localOnly, ...pending]);
        };
        pendingRequest.onerror = () => reject(pendingRequest.error);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async markFileSynced(localId: string, serverId: number): Promise<void> {
    if (!this.db) await this.initDB();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['files'], 'readwrite');
      const store = transaction.objectStore('files');
      const request = store.get(localId);
      
      request.onsuccess = () => {
        const file = request.result;
        if (file) {
          file.serverId = serverId;
          file.syncStatus = 'synced';
          const updateRequest = store.put(file);
          updateRequest.onsuccess = () => resolve();
          updateRequest.onerror = () => reject(updateRequest.error);
        } else {
          reject(new Error('File not found'));
        }
      };
      request.onerror = () => reject(request.error);
    });
  }

  // Utility methods
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  private async saveToStore<T>(storeName: string, data: T): Promise<T> {
    if (!this.db) await this.initDB();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.add(data);
      
      request.onsuccess = () => resolve(data);
      request.onerror = () => reject(request.error);
    });
  }

  // Check if online
  isOnline(): boolean {
    return navigator.onLine;
  }

  // Settings operations
  async saveSettings(userId: number, settings: any): Promise<void> {
    if (!this.db) await this.initDB();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['settings'], 'readwrite');
      const store = transaction.objectStore('settings');
      const request = store.put({ userId, ...settings });
      
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getSettings(userId: number): Promise<any> {
    if (!this.db) await this.initDB();
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['settings'], 'readonly');
      const store = transaction.objectStore('settings');
      const request = store.get(userId);
      
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }
}

export const offlineStorage = new OfflineStorage();
export type { OfflineFile, OfflineUser };