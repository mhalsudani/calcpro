// Smart sync manager for hybrid online/offline storage
import { offlineStorage, type OfflineFile, type OfflineUser } from './offlineStorage';
import { apiRequest } from './queryClient';

class SyncManager {
  private syncInProgress = false;
  private syncQueue: (() => Promise<void>)[] = [];

  constructor() {
    // Listen for online/offline events
    window.addEventListener('online', () => this.onConnectionChange(true));
    window.addEventListener('offline', () => this.onConnectionChange(false));
    
    // Initialize offline storage
    offlineStorage.initDB();
  }

  private async onConnectionChange(isOnline: boolean) {
    if (isOnline && !this.syncInProgress) {
      console.log('🔄 Connection restored, starting sync...');
      await this.syncAll();
    } else if (!isOnline) {
      console.log('📱 Working offline...');
    }
  }

  // Main sync function
  async syncAll(): Promise<void> {
    if (this.syncInProgress) return;
    
    this.syncInProgress = true;
    
    try {
      // Process sync queue
      while (this.syncQueue.length > 0) {
        const syncTask = this.syncQueue.shift();
        if (syncTask) {
          await syncTask();
        }
      }
      
      // Sync unsynced files
      await this.syncUnsyncedFiles();
      
      console.log('✅ Sync completed successfully');
    } catch (error) {
      console.error('❌ Sync failed:', error);
    } finally {
      this.syncInProgress = false;
    }
  }

  // User operations with hybrid storage
  async createUser(pin: string, securityQuestion?: string, securityAnswer?: string): Promise<{ id: number; pin: string }> {
    if (offlineStorage.isOnline()) {
      // Try online first
      try {
        console.log('Sending PIN to server:', pin);
        const response = await apiRequest("POST", "/api/users", { 
          pin, 
          securityQuestion, 
          securityAnswer 
        });
        const serverUser = await response.json();
        console.log('Server response successful:', serverUser);
        
        // Save to offline storage as backup
        const offlineUser = await offlineStorage.createUser({ pin });
        await this.markUserSynced(offlineUser.localId, serverUser.id);
        
        return { id: serverUser.id, pin };
      } catch (error) {
        console.error('Server error:', error);
        
        // Check if error message contains PIN already exists
        const errorMessage = (error as any)?.message || '';
        if (errorMessage.includes('PIN_ALREADY_EXISTS') || errorMessage.includes('PIN already exists')) {
          throw new Error('PIN_ALREADY_EXISTS');
        }
        
        // Fallback to offline
        const offlineUser = await offlineStorage.createUser({ pin });
        this.addToSyncQueue(() => this.syncUser(offlineUser));
        return { id: parseInt(offlineUser.localId), pin };
      }
    } else {
      // Offline only
      const offlineUser = await offlineStorage.createUser({ pin });
      this.addToSyncQueue(() => this.syncUser(offlineUser));
      return { id: parseInt(offlineUser.localId), pin };
    }
  }

  // PIN Recovery function
  async recoverPin(securityAnswer: string): Promise<string | null> {
    if (offlineStorage.isOnline()) {
      try {
        const response = await apiRequest("POST", "/api/recover-pin", { securityAnswer });
        const result = await response.json();
        return result.pin;
      } catch (error) {
        console.error('PIN recovery failed:', error);
        return null;
      }
    }
    return null;
  }

  async authenticateUser(pin: string): Promise<{ id: number; pin: string } | null> {
    // Try offline first for speed
    const offlineUser = await offlineStorage.getUserByPin(pin);
    if (offlineUser) {
      return { 
        id: offlineUser.serverId || parseInt(offlineUser.localId), 
        pin 
      };
    }

    // Try online if not found offline
    if (offlineStorage.isOnline()) {
      try {
        const response = await apiRequest("POST", "/api/auth", { pin });
        const serverUser = await response.json();
        
        // Save to offline for future use
        await offlineStorage.createUser({ pin });
        
        return { id: serverUser.id, pin };
      } catch (error) {
        return null;
      }
    }
    
    return null;
  }

  // File operations with hybrid storage
  async createFile(fileData: {
    name: string;
    type: string;
    size: number;
    mimeType: string;
    data: string;
    userId: number;
  }): Promise<any> {
    // Always save locally first for immediate response
    const offlineFile = await offlineStorage.createFile(fileData);
    
    if (offlineStorage.isOnline()) {
      // Try to sync immediately
      try {
        const response = await apiRequest("POST", "/api/files", fileData);
        const serverFile = await response.json();
        
        // Mark as synced
        await offlineStorage.markFileSynced(offlineFile.localId, serverFile.id);
        
        return serverFile;
      } catch (error) {
        // Will sync later when online
        this.addToSyncQueue(() => this.syncFile(offlineFile));
        return { ...offlineFile, id: parseInt(offlineFile.localId) };
      }
    } else {
      // Add to sync queue for later
      this.addToSyncQueue(() => this.syncFile(offlineFile));
      return { ...offlineFile, id: parseInt(offlineFile.localId) };
    }
  }

  async getFiles(userId: number): Promise<any[]> {
    // Get offline files first
    const offlineFiles = await offlineStorage.getFilesByUserId(userId);
    
    if (offlineStorage.isOnline()) {
      // Try to get fresh data from server
      try {
        const response = await fetch(`/api/files?userId=${userId}`, {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        });
        
        if (response.ok) {
          const serverFiles = await response.json();
          // Merge with offline files (prioritize server data for synced files)
          return this.mergeFiles(offlineFiles, serverFiles);
        }
      } catch (error) {
        console.log('📱 Using offline data only');
      }
    }
    
    // Return offline files with proper format
    return offlineFiles.map(file => ({
      ...file,
      id: file.serverId || parseInt(file.localId)
    }));
  }

  async deleteFile(fileId: string | number, userId: number): Promise<boolean> {
    // Delete locally first
    const localId = typeof fileId === 'string' ? fileId : fileId.toString();
    await offlineStorage.deleteFile(localId);
    
    if (offlineStorage.isOnline()) {
      // Try to delete from server
      try {
        await apiRequest("DELETE", `/api/files/${fileId}`, { userId });
        return true;
      } catch (error) {
        // Will handle deletion when back online
        console.log('File deleted locally, will sync deletion when online');
        return true;
      }
    }
    
    return true;
  }

  // Sync helper methods
  private async syncUnsyncedFiles(): Promise<void> {
    const unsyncedFiles = await offlineStorage.getUnsyncedFiles();
    
    for (const file of unsyncedFiles) {
      await this.syncFile(file);
    }
  }

  private async syncFile(file: OfflineFile): Promise<void> {
    if (!offlineStorage.isOnline()) return;
    
    try {
      const response = await apiRequest("POST", "/api/files", {
        name: file.name,
        type: file.type,
        size: file.size,
        mimeType: file.mimeType,
        data: file.data,
        userId: file.userId,
      });
      
      const serverFile = await response.json();
      await offlineStorage.markFileSynced(file.localId, serverFile.id);
      
      console.log(`✅ Synced file: ${file.name}`);
    } catch (error) {
      console.error(`❌ Failed to sync file: ${file.name}`, error);
    }
  }

  private async syncUser(user: OfflineUser): Promise<void> {
    if (!offlineStorage.isOnline()) return;
    
    try {
      const response = await apiRequest("POST", "/api/users", { pin: user.pin });
      const serverUser = await response.json();
      await this.markUserSynced(user.localId, serverUser.id);
      
      console.log(`✅ Synced user with PIN: ${user.pin}`);
    } catch (error) {
      console.error(`❌ Failed to sync user`, error);
    }
  }

  private async markUserSynced(localId: string, serverId: number): Promise<void> {
    // Implementation for marking user as synced
    // This would be similar to markFileSynced but for users
  }

  private mergeFiles(offlineFiles: OfflineFile[], serverFiles: any[]): any[] {
    const merged = [...serverFiles];
    
    // Add local-only files that haven't been synced yet
    const localOnlyFiles = offlineFiles.filter(
      local => local.syncStatus === 'local-only' || local.syncStatus === 'pending'
    );
    
    localOnlyFiles.forEach(local => {
      merged.push({
        ...local,
        id: parseInt(local.localId)
      });
    });
    
    return merged;
  }

  private addToSyncQueue(task: () => Promise<void>): void {
    this.syncQueue.push(task);
    
    // If online, try to process queue immediately
    if (offlineStorage.isOnline() && !this.syncInProgress) {
      this.syncAll();
    }
  }

  // Public method to check connection status
  isOnline(): boolean {
    return offlineStorage.isOnline();
  }

  // Force sync (for manual sync button)
  async forcSync(): Promise<void> {
    if (offlineStorage.isOnline()) {
      await this.syncAll();
    }
  }
}

export const syncManager = new SyncManager();