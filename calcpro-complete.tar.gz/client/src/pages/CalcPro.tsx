import { useState, useEffect } from "react";
import { Calculator } from "@/components/Calculator";
import { FileManager } from "@/components/FileManager";
import { PinSetup } from "@/components/PinSetup";
import { useTheme } from "@/hooks/useTheme";

type View = "calculator" | "pin-setup" | "file-manager";

export default function CalcPro() {
  const [currentView, setCurrentView] = useState<View>("calculator");
  const [currentUser, setCurrentUser] = useState<{ id: number; pin: string } | null>(null);
  const { theme } = useTheme();

  useEffect(() => {
    // Check if user has already set up PIN
    const hasPin = localStorage.getItem("calcpro_pin_setup");
    if (!hasPin) {
      setCurrentView("pin-setup");
    } else {
      setCurrentView("calculator");
    }
  }, []);

  const handlePinSetup = (pin: string, userId: number) => {
    localStorage.setItem("calcpro_pin_setup", "true");
    setCurrentUser({ id: userId, pin });
    setCurrentView("calculator");
  };

  const handleSecretAccess = (userId: number, pin: string) => {
    setCurrentUser({ id: userId, pin });
    setCurrentView("file-manager");
  };

  const handleBackToCalculator = () => {
    setCurrentView("calculator");
  };

  const handleSetupNewPin = () => {
    setCurrentView("pin-setup");
  };

  return (
    <div className="min-h-screen bg-[#F2F2F7] dark:bg-[#1C1C1E] transition-colors duration-300">
      <div className="max-w-md mx-auto min-h-screen flex flex-col">
        {/* Main Content */}
        <div className="flex-1">
          {currentView === "pin-setup" && (
            <PinSetup 
              onPinSetup={handlePinSetup} 
              onBackToCalculator={handleBackToCalculator}
            />
          )}
          
          {currentView === "calculator" && (
            <Calculator 
              onSecretAccess={handleSecretAccess} 
              onSetupNewPin={handleSetupNewPin}
            />
          )}
          
          {currentView === "file-manager" && currentUser && (
            <FileManager 
              userId={currentUser.id} 
              onBackToCalculator={handleBackToCalculator}
            />
          )}
        </div>
      </div>
    </div>
  );
}
