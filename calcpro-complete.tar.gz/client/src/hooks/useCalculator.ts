import { useState } from "react";

export function useCalculator() {
  const [display, setDisplay] = useState("0");
  const [previousNumber, setPreviousNumber] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [shouldResetDisplay, setShouldResetDisplay] = useState(false);

  const handleNumberClick = (number: string) => {
    if (shouldResetDisplay) {
      setDisplay(number);
      setShouldResetDisplay(false);
    } else {
      setDisplay(prev => prev === "0" ? number : prev + number);
    }
  };

  const handleOperationClick = (op: string) => {
    const current = parseFloat(display);
    
    if (previousNumber !== null && operation !== null && !shouldResetDisplay) {
      const result = calculate(previousNumber, current, operation);
      setDisplay(result.toString());
      setPreviousNumber(result);
    } else {
      setPreviousNumber(current);
    }
    
    setOperation(op);
    setShouldResetDisplay(true);
  };

  const handleEquals = () => {
    if (operation && previousNumber !== null) {
      const current = parseFloat(display);
      const result = calculate(previousNumber, current, operation);
      setDisplay(result.toString());
      setOperation(null);
      setPreviousNumber(null);
      setShouldResetDisplay(true);
    }
  };

  const handleClear = () => {
    setDisplay("0");
    setOperation(null);
    setPreviousNumber(null);
    setShouldResetDisplay(false);
  };

  const handleDecimal = () => {
    if (!display.includes(".")) {
      setDisplay(prev => prev + ".");
    }
  };

  const handleToggleSign = () => {
    if (display !== "0") {
      setDisplay(prev => prev.startsWith("-") ? prev.slice(1) : "-" + prev);
    }
  };

  const handlePercentage = () => {
    const current = parseFloat(display);
    setDisplay((current / 100).toString());
  };

  const calculate = (first: number, second: number, operation: string): number => {
    switch (operation) {
      case "add":
        return first + second;
      case "subtract":
        return first - second;
      case "multiply":
        return first * second;
      case "divide":
        return second !== 0 ? first / second : 0;
      default:
        return second;
    }
  };

  return {
    display,
    handleNumberClick,
    handleOperationClick,
    handleEquals,
    handleClear,
    handleDecimal,
    handleToggleSign,
    handlePercentage,
  };
}
