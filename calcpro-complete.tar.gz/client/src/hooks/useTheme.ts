import { useContext } from "react";
import { ThemeProvider } from "@/components/ThemeProvider";

// Re-export the useTheme hook from ThemeProvider
export { useTheme } from "@/components/ThemeProvider";
