import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { syncManager } from "@/lib/syncManager";
import { useTheme } from "@/components/ThemeProvider";

interface FileType {
  id: number;
  name: string;
  type: "image" | "video" | "document";
  size: number;
  mimeType: string;
  data: string;
  userId: number;
}

interface FileManagerProps {
  userId: number;
  onBackToCalculator: () => void;
}

export function FileManager({ userId, onBackToCalculator }: FileManagerProps) {
  const [files, setFiles] = useState<FileType[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<"all" | "image" | "video" | "document">("all");
  const [selectedFile, setSelectedFile] = useState<FileType | null>(null);
  const [language, setLanguage] = useState<"ar" | "en">("ar");
  const [isUploading, setIsUploading] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const { theme, toggleTheme } = useTheme();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const t = {
    images: language === "ar" ? "الصور" : "Images",
    videos: language === "ar" ? "الفيديوهات" : "Videos", 
    docs: language === "ar" ? "المستندات" : "Documents"
  };

  useEffect(() => {
    // Load files immediately on mount
    loadFiles();
  }, [userId]);

  // Calculate file counts for better performance
  const fileCounts = {
    images: files.filter(f => f.type === 'image').length,
    videos: files.filter(f => f.type === 'video').length,  
    documents: files.filter(f => f.type === 'document').length,
    total: files.length
  };

  const loadFiles = async () => {
    try {
      setIsLoading(true);
      
      // Show UI immediately with empty counts, then load data
      setTimeout(() => setIsLoading(false), 100);
      
      const userFiles = await syncManager.getFiles(userId);
      setFiles(userFiles);
    } catch (error) {
      console.error("Error loading files:", error);
      setIsLoading(false);
    }
  };

  const getFilesByType = (type: string) => {
    if (type === "all") return files;
    return files.filter(file => file.type === type);
  };

  const handleFileUpload = (fileList: FileList) => {
    Array.from(fileList).forEach(file => {
      if (file.size > 50 * 1024 * 1024) {
        toast({
          title: language === "ar" ? "خطأ" : "Error",
          description: language === "ar" ? "حجم الملف كبير جداً (الحد الأقصى 50 ميجابايت)" : "File too large (max 50MB)",
          variant: "destructive"
        });
        return;
      }

      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          setIsUploading(true);
          const base64Data = (e.target?.result as string).split(',')[1];
          
          let fileType: "image" | "video" | "document" = "document";
          if (file.type.startsWith('image/')) fileType = "image";
          else if (file.type.startsWith('video/')) fileType = "video";

          await syncManager.createFile({
            name: file.name,
            type: fileType,
            size: file.size,
            mimeType: file.type,
            data: base64Data,
            userId
          });

          await loadFiles();
          toast({
            title: language === "ar" ? "نجح الرفع" : "Upload Success",
            description: language === "ar" ? `تم رفع ${file.name}` : `${file.name} uploaded`
          });
        } catch (error) {
          toast({
            title: language === "ar" ? "خطأ في الرفع" : "Upload Error",
            description: language === "ar" ? "فشل في رفع الملف" : "Failed to upload file",
            variant: "destructive"
          });
        } finally {
          setIsUploading(false);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDeleteFile = async (fileId: number) => {
    try {
      await syncManager.deleteFile(fileId, userId);
      await loadFiles();
      toast({
        title: language === "ar" ? "تم الحذف" : "Deleted",
        description: language === "ar" ? "تم حذف الملف" : "File deleted"
      });
    } catch (error) {
      toast({
        title: language === "ar" ? "خطأ" : "Error",
        description: language === "ar" ? "فشل في حذف الملف" : "Failed to delete file",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-3 sm:p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 space-y-4 sm:space-y-0">
          <div className="flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <Button
              onClick={onBackToCalculator}
              variant="outline"
              size="sm"
              className="bg-red-100 hover:bg-red-200 text-red-700 border-red-300 w-fit"
            >
              ← {language === "ar" ? "العودة للآلة الحاسبة" : "Back to Calculator"}
            </Button>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
              {language === "ar" ? "إدارة الملفات" : "File Manager"}
            </h1>
          </div>
          <div className="flex items-center space-x-3">
            <h1 className="text-lg font-bold text-gray-900 dark:text-white">
              CalcPro
            </h1>
            <Button
              onClick={toggleTheme}
              variant="outline"
              size="sm"
              className="px-3 py-2 bg-black dark:bg-white text-white dark:text-black border-gray-600 dark:border-gray-300 hover:bg-gray-800 dark:hover:bg-gray-100"
            >
              {theme === "light" ? "🌙" : "☀️"}
            </Button>
            <Button
              onClick={() => setLanguage(language === "ar" ? "en" : "ar")}
              variant="outline"
              className="bg-black dark:bg-white text-white dark:text-black border-gray-600 dark:border-gray-300 hover:bg-gray-800 dark:hover:bg-gray-100"
            >
              {language === "ar" ? "English" : "العربية"}
            </Button>
          </div>
        </div>

        {/* Security Notice */}
        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl p-4 mb-6">
          <div className="flex items-center space-x-3">
            <div className="text-green-600 dark:text-green-400 text-xl">🔒</div>
            <div>
              <h3 className="text-sm font-semibold text-green-800 dark:text-green-300 mb-1">
                {language === "ar" ? "ملفاتك محفوظة بأمان" : "Your Files Are Secure"}
              </h3>
              <p className="text-xs text-green-700 dark:text-green-400">
                {language === "ar" 
                  ? "جميع ملفاتك محفوظة في السحابة ويمكن استعادتها على أي جهاز جديد باستخدام نفس رقم PIN"
                  : "All your files are safely stored in the cloud and can be recovered on any new device using the same PIN"
                }
              </p>
            </div>
          </div>
        </div>

        {/* File Upload */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 sm:p-6 shadow-lg mb-6">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white mb-4">
            {language === "ar" ? "رفع ملفات جديدة" : "Upload New Files"}
          </h2>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => {
              if (e.target.files) {
                handleFileUpload(e.target.files);
                e.target.value = '';
              }
            }}
          />
          <Button
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            {isUploading 
              ? (language === "ar" ? "جاري الرفع..." : "Uploading...")
              : (language === "ar" ? "📁 اختر الملفات" : "📁 Choose Files")
            }
          </Button>
        </div>

        {/* File Viewer - shows when file is selected */}
        {selectedFile && (
          <div className="mb-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
              <button
                onClick={() => setSelectedFile(null)}
                className="text-blue-600 hover:text-blue-700 font-medium"
              >
                ← رجوع للملفات
              </button>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white">{selectedFile.name}</h3>
            </div>
            <div className="p-6">
              {selectedFile.type === "image" && (
                <img
                  src={`data:${selectedFile.mimeType};base64,${selectedFile.data}`}
                  alt={selectedFile.name}
                  className="w-full h-auto rounded-lg cursor-default"
                  onClick={(e) => e.preventDefault()}
                />
              )}
              {selectedFile.type === "video" && (
                <video
                  src={`data:${selectedFile.mimeType};base64,${selectedFile.data}`}
                  controls
                  className="w-full h-auto rounded-lg"
                />
              )}
              {selectedFile.type === "document" && (
                <div className="space-y-6">
                  {/* PDF Viewer */}
                  {selectedFile.mimeType === "application/pdf" && (
                    <div className="w-full">
                      <iframe
                        src={`data:${selectedFile.mimeType};base64,${selectedFile.data}`}
                        className="w-full h-96 rounded-lg border border-gray-300 dark:border-gray-600"
                        title={selectedFile.name}
                      />
                    </div>
                  )}
                  
                  {/* Text Files Viewer */}
                  {(selectedFile.mimeType.includes("text/") || selectedFile.name.endsWith('.txt')) && (
                    <div className="w-full">
                      <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 max-h-96 overflow-auto">
                        <pre className="text-sm text-gray-800 dark:text-gray-200 whitespace-pre-wrap">
                          {atob(selectedFile.data)}
                        </pre>
                      </div>
                    </div>
                  )}
                  
                  {/* Office Documents and Others */}
                  {!selectedFile.mimeType.includes("text/") && selectedFile.mimeType !== "application/pdf" && (
                    <div>
                      {/* Word Documents */}
                      {(selectedFile.mimeType.includes("application/vnd.openxmlformats-officedocument.wordprocessingml") || 
                        selectedFile.mimeType.includes("application/msword") ||
                        selectedFile.name.endsWith('.docx') || selectedFile.name.endsWith('.doc')) && (
                        <div className="w-full">
                          <div className="bg-blue-50 dark:bg-blue-900/10 rounded-lg p-6 text-center">
                            <div className="w-20 h-20 mx-auto mb-4 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
                              <svg className="w-10 h-10 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M13,9V3.5L18.5,9M6,2C4.89,2 4,2.89 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2H6Z"/>
                              </svg>
                            </div>
                            <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{selectedFile.name}</h4>
                            <p className="text-gray-600 dark:text-gray-400 mb-4">
                              مستند Word - حجم: {(selectedFile.size / 1024 / 1024).toFixed(2)} ميجابايت
                            </p>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                              مستندات Word تحتاج تطبيق خارجي للعرض الكامل
                            </p>
                            <a
                              href={`data:${selectedFile.mimeType};base64,${selectedFile.data}`}
                              download={selectedFile.name}
                              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg inline-flex items-center space-x-2"
                            >
                              <span>📥</span>
                              <span>تحميل وفتح</span>
                            </a>
                          </div>
                        </div>
                      )}
                      
                      {/* Excel Documents */}
                      {(selectedFile.mimeType.includes("application/vnd.openxmlformats-officedocument.spreadsheetml") || 
                        selectedFile.mimeType.includes("application/vnd.ms-excel") ||
                        selectedFile.name.endsWith('.xlsx') || selectedFile.name.endsWith('.xls')) && (
                        <div className="w-full">
                          <div className="bg-green-50 dark:bg-green-900/10 rounded-lg p-6 text-center">
                            <div className="w-20 h-20 mx-auto mb-4 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
                              <svg className="w-10 h-10 text-green-600" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M13,9V3.5L18.5,9M6,2C4.89,2 4,2.89 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2H6Z"/>
                              </svg>
                            </div>
                            <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{selectedFile.name}</h4>
                            <p className="text-gray-600 dark:text-gray-400 mb-4">
                              جدول Excel - حجم: {(selectedFile.size / 1024 / 1024).toFixed(2)} ميجابايت
                            </p>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                              انقر على "تحميل الملف" لفتح الجدول في تطبيق Excel
                            </p>
                          </div>
                        </div>
                      )}
                      
                      {/* PowerPoint Documents */}
                      {(selectedFile.mimeType.includes("application/vnd.openxmlformats-officedocument.presentationml") || 
                        selectedFile.mimeType.includes("application/vnd.ms-powerpoint") ||
                        selectedFile.name.endsWith('.pptx') || selectedFile.name.endsWith('.ppt')) && (
                        <div className="w-full">
                          <div className="bg-orange-50 dark:bg-orange-900/10 rounded-lg p-6 text-center">
                            <div className="w-20 h-20 mx-auto mb-4 bg-orange-100 dark:bg-orange-900/20 rounded-full flex items-center justify-center">
                              <svg className="w-10 h-10 text-orange-600" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M13,9V3.5L18.5,9M6,2C4.89,2 4,2.89 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2H6Z"/>
                              </svg>
                            </div>
                            <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{selectedFile.name}</h4>
                            <p className="text-gray-600 dark:text-gray-400 mb-4">
                              عرض PowerPoint - حجم: {(selectedFile.size / 1024 / 1024).toFixed(2)} ميجابايت
                            </p>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                              انقر على "تحميل الملف" لفتح العرض في تطبيق PowerPoint
                            </p>
                          </div>
                        </div>
                      )}
                      
                      {/* Other Documents */}
                      {!selectedFile.mimeType.includes("application/vnd.openxmlformats-officedocument") && 
                       !selectedFile.mimeType.includes("application/msword") &&
                       !selectedFile.mimeType.includes("application/vnd.ms-excel") &&
                       !selectedFile.mimeType.includes("application/vnd.ms-powerpoint") &&
                       !selectedFile.name.endsWith('.docx') && !selectedFile.name.endsWith('.doc') &&
                       !selectedFile.name.endsWith('.xlsx') && !selectedFile.name.endsWith('.xls') &&
                       !selectedFile.name.endsWith('.pptx') && !selectedFile.name.endsWith('.ppt') && (
                        <div className="text-center py-8">
                          <div className="w-20 h-20 mx-auto mb-4 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
                            <svg className="w-10 h-10 text-gray-600" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M13,9V3.5L18.5,9M6,2C4.89,2 4,2.89 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2H6Z"/>
                            </svg>
                          </div>
                          <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{selectedFile.name}</h4>
                          <p className="text-gray-600 dark:text-gray-400 mb-4">
                            حجم الملف: {(selectedFile.size / 1024 / 1024).toFixed(2)} ميجابايت
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                            انقر على "تحميل الملف" لفتح هذا الملف في التطبيق المناسب
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                  

                </div>
              )}
            </div>
          </div>
        )}

        {/* Category Icons - only show when no file is selected */}
        {!selectedFile && (
          <div className="grid grid-cols-3 gap-3 mb-6">
            <div
              onClick={() => setSelectedCategory("image")}
              className={`aspect-square cursor-pointer rounded-xl overflow-hidden relative shadow-md hover:shadow-lg transition-all transform hover:scale-105 ${selectedCategory === "image" ? "ring-2 ring-green-500" : ""} bg-gradient-to-br from-green-400 to-blue-500`}
            >
              <div className="w-full h-full flex flex-col items-center justify-center p-4 text-white">
                <svg className="w-12 h-12 mb-2 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"/>
                </svg>
                <span className="text-sm font-bold text-center">{t.images}</span>
                <span className="text-xs">({fileCounts.images})</span>
              </div>
            </div>
            
            <div
              onClick={() => setSelectedCategory("video")}
              className={`aspect-square cursor-pointer rounded-xl overflow-hidden relative shadow-md hover:shadow-lg transition-all transform hover:scale-105 ${selectedCategory === "video" ? "ring-2 ring-purple-500" : ""} bg-gradient-to-br from-purple-500 to-pink-500`}
            >
              <div className="w-full h-full flex flex-col items-center justify-center p-4 text-white">
                <svg className="w-12 h-12 mb-2 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z"/>
                </svg>
                <span className="text-sm font-bold text-center">{t.videos}</span>
                <span className="text-xs">({fileCounts.videos})</span>
              </div>
            </div>
            
            <div
              onClick={() => setSelectedCategory("document")}
              className={`aspect-square cursor-pointer rounded-xl overflow-hidden relative shadow-md hover:shadow-lg transition-all transform hover:scale-105 ${selectedCategory === "document" ? "ring-2 ring-orange-500" : ""} bg-gradient-to-br from-orange-400 to-red-500`}
            >
              <div className="w-full h-full flex flex-col items-center justify-center p-4 text-white">
                <svg className="w-12 h-12 mb-2 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z"/>
                </svg>
                <span className="text-sm font-bold text-center">{t.docs}</span>
                <span className="text-xs">({fileCounts.documents})</span>
              </div>
            </div>
          </div>
        )}

        {/* File List - only show when category is selected and no file is being viewed */}
        {selectedCategory !== "all" && !selectedFile && (
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                {selectedCategory === "image" ? t.images : selectedCategory === "video" ? t.videos : t.docs}
              </h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedCategory("all")}
                className="text-gray-600 dark:text-gray-300"
              >
                {language === "ar" ? "عرض الكل" : "View All"}
              </Button>
            </div>
            
            {getFilesByType(selectedCategory).length === 0 ? (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                {language === "ar" ? "لا توجد ملفات في هذه الفئة" : "No files in this category"}
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {getFilesByType(selectedCategory).map((file) => (
                  <div
                    key={file.id}
                    className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border dark:border-gray-700 w-full cursor-pointer hover:scale-105"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setSelectedFile(file);
                    }}
                  >
                    <div className="flex items-center space-x-6">
                      <div className="flex-shrink-0">
                        {file.type === "video" && (
                          <div className="w-24 h-24 bg-red-100 dark:bg-red-900/20 rounded-2xl flex items-center justify-center">
                            <svg className="h-16 w-16 text-red-600" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M17,10.5V7A1,1 0 0,0 16,6H4A1,1 0 0,0 3,7V17A1,1 0 0,0 4,18H16A1,1 0 0,0 17,17V13.5L21,17.5V6.5L17,10.5Z"/>
                            </svg>
                          </div>
                        )}
                        {file.type === "image" && (
                          <div className="w-24 h-24 bg-blue-100 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center">
                            <svg className="h-16 w-16 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M8.5,13.5L11,16.5L14.5,12L19,18H5M21,19V5C21,3.89 20.1,3 19,3H5A2,2 0 0,0 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19Z"/>
                            </svg>
                          </div>
                        )}
                        {file.type === "document" && (
                          <div className="w-24 h-24 bg-orange-100 dark:bg-orange-900/20 rounded-2xl flex items-center justify-center">
                            <svg className="h-16 w-16 text-orange-600" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M13,9V3.5L18.5,9M6,2C4.89,2 4,2.89 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2H6Z"/>
                            </svg>
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-2 break-words">
                          {file.name}
                        </h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
                          {(file.size / 1024 / 1024).toFixed(2)} ميجابايت
                        </p>
                        <div className="flex items-center justify-between">
                          <span className={`inline-block px-4 py-2 text-sm font-medium rounded-full ${
                            file.type === "image" ? "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400" :
                            file.type === "video" ? "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400" :
                            "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400"
                          }`}>
                            {file.type === "image" ? "صورة" : file.type === "video" ? "فيديو" : "مستند"}
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteFile(file.id);
                            }}
                            className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm"
                          >
                            🗑️ حذف
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}