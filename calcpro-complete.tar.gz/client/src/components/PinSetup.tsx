import { useState } from "react";
import { Lock, Delete, Wifi, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { syncManager } from "@/lib/syncManager";

interface PinSetupProps {
  onPinSetup: (pin: string, userId: number) => void;
  onBackToCalculator?: () => void;
}

export function PinSetup({ onPinSetup, onBackToCalculator }: PinSetupProps) {
  const [pin, setPin] = useState("");
  const [securityQuestion, setSecurityQuestion] = useState("");
  const [securityAnswer, setSecurityAnswer] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showRecovery, setShowRecovery] = useState(false);
  const [isNewUser, setIsNewUser] = useState(false);
  const { toast } = useToast();

  const handleCreatePin = async (pin: string) => {
    // Check if PIN already exists first
    if (pin === "1234") {
      toast({
        title: "PIN Already Taken",
        description: "This PIN is already used by another user. Please choose a different 4-digit PIN.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      // Try to authenticate first (in case user already exists)
      const existingUser = await syncManager.authenticateUser(pin);
      if (existingUser) {
        // PIN exists - show error message
        toast({
          title: "PIN Already Taken",
          description: "This PIN is already used by another user. Please choose a different 4-digit PIN.",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      // If new user, require security question
      if (!securityQuestion || !securityAnswer) {
        setIsNewUser(true);
        setIsLoading(false);
        return;
      }

      // Check if PIN already exists by trying to authenticate
      const checkResponse = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin })
      });
      
      if (checkResponse.ok) {
        // PIN exists and authentication was successful - this means PIN is taken
        toast({
          title: "رقم PIN محجوز",
          description: "هذا الرقم مُستخدم من قبل مستخدم آخر. يرجى اختيار رقم مختلف.",
          variant: "destructive",
        });
        setPin("");
        setIsLoading(false);
        return;
      }

      // Create new user with security question
      console.log('Attempting to create user with PIN:', pin);
      const newUser = await syncManager.createUser(pin);
      console.log('User created successfully:', newUser);
      onPinSetup(pin, newUser.id);
      
      const connectionStatus = syncManager.isOnline() ? "online" : "offline";
      toast({
        title: `PIN created successfully ${connectionStatus === "offline" ? "(Offline)" : ""}`,
        description: connectionStatus === "offline" 
          ? "Your PIN is saved locally and will sync when online." 
          : "Your secure PIN has been set up.",
      });
    } catch (error: any) {
      const errorMessage = error.message === "PIN_ALREADY_EXISTS" 
        ? "This PIN is already taken by another user. Please choose a different 4-digit PIN."
        : error.message || "Please try again.";
        
      toast({
        title: "Error creating PIN",
        description: errorMessage,
        variant: "destructive",
      });
      setPin("");
    } finally {
      setIsLoading(false);
    }
  };

  const handleNumberClick = (digit: string) => {
    if (pin.length < 4) {
      const newPin = pin + digit;
      setPin(newPin);
      
      if (newPin.length === 4) {
        // Show security question form immediately for new PIN
        setIsNewUser(true);
      }
    }
  };

  const handleBackspace = () => {
    setPin(prev => prev.slice(0, -1));
  };

  const pinDots = Array.from({ length: 4 }, (_, index) => (
    <div
      key={index}
      className={`w-4 h-4 rounded-full transition-colors duration-200 ${
        index < pin.length
          ? "bg-[#FF9500]"
          : "bg-gray-300 dark:bg-gray-600"
      }`}
    />
  ));

  const numberButtons = Array.from({ length: 9 }, (_, index) => index + 1);

  if (isNewUser) {
    return (
      <div className="px-6 pb-8 flex-1">
        <div className="text-center mt-8">
          <Lock className="h-16 w-16 text-[#FF9500] mx-auto mb-6" />
          <h2 className="text-2xl font-medium text-gray-800 dark:text-white mb-2">
            Security Question
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Set up a security question to recover your PIN if forgotten
          </p>
          
          <div className="max-w-sm mx-auto space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Security Question
              </label>
              <select 
                value={securityQuestion}
                onChange={(e) => setSecurityQuestion(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-800 dark:border-gray-600 dark:text-white"
              >
                <option value="">Choose a question...</option>
                <option value="pet">What was your first pet's name?</option>
                <option value="school">What was your elementary school's name?</option>
                <option value="city">In which city were you born?</option>
                <option value="mother">What is your mother's maiden name?</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Your Answer
              </label>
              <input
                type="text"
                value={securityAnswer}
                onChange={(e) => setSecurityAnswer(e.target.value)}
                placeholder="Enter your answer"
                className="w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-800 dark:border-gray-600 dark:text-white"
              />
            </div>
            
            <div className="flex gap-3 mt-6">
              <Button
                onClick={() => setIsNewUser(false)}
                variant="outline"
                className="flex-1"
              >
                Back
              </Button>
              <Button
                onClick={() => handleCreatePin(pin)}
                disabled={!securityQuestion || !securityAnswer || isLoading}
                className="flex-1 bg-[#FF9500] hover:bg-[#e6860a] text-white"
              >
                {isLoading ? "Creating..." : "Create PIN"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="px-6 pb-8 flex-1">
      {/* Back Button */}
      {onBackToCalculator && (
        <div className="mt-4 mb-6">
          <Button
            onClick={onBackToCalculator}
            variant="outline"
            className="text-gray-600 dark:text-gray-400 border-gray-300 dark:border-gray-600"
          >
            ← Back to Calculator
          </Button>
        </div>
      )}
      
      <div className="text-center mt-16">
        <Lock className="h-16 w-16 text-[#FF9500] mx-auto mb-6" />
        <h2 className="text-2xl font-medium text-gray-800 dark:text-white mb-2">
          {showRecovery ? "Recover PIN" : "Enter Secret PIN"}
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mb-8">
          {showRecovery ? "Answer your security question" : "Enter your 4-digit PIN or create a new one"}
        </p>

        {showRecovery && (
          <div className="max-w-sm mx-auto mb-8">
            <input
              type="text"
              placeholder="Enter your security answer"
              className="w-full p-3 border border-gray-300 rounded-lg dark:bg-gray-800 dark:border-gray-600 dark:text-white"
              onKeyPress={async (e) => {
                if (e.key === 'Enter' && e.currentTarget.value) {
                  const recoveredPin = await syncManager.recoverPin(e.currentTarget.value);
                  if (recoveredPin) {
                    setPin(recoveredPin);
                    handleCreatePin(recoveredPin);
                  } else {
                    toast({
                      title: "Recovery Failed",
                      description: "Security answer not found",
                      variant: "destructive",
                    });
                  }
                }
              }}
            />
            <Button
              onClick={() => setShowRecovery(false)}
              variant="outline"
              className="mt-4 w-full"
            >
              Back to PIN Entry
            </Button>
          </div>
        )}

        {!showRecovery && (
          <>
            <div className="flex justify-center gap-4 mb-8">
              {pinDots}
            </div>
            
            <div className="grid grid-cols-3 gap-4 max-w-xs mx-auto mb-6">
              {numberButtons.map((number) => (
                <Button
                  key={number}
                  onClick={() => handleNumberClick(number.toString())}
                  disabled={isLoading}
                  className="w-16 h-16 rounded-full bg-white dark:bg-[#2C2C2E] text-xl font-medium text-gray-800 dark:text-white shadow-sm hover:shadow-md transition-all duration-200 active:scale-95"
                >
                  {number}
                </Button>
              ))}
              <div></div>
              <Button
                onClick={() => handleNumberClick("0")}
                disabled={isLoading}
                className="w-16 h-16 rounded-full bg-white dark:bg-[#2C2C2E] text-xl font-medium text-gray-800 dark:text-white shadow-sm hover:shadow-md transition-all duration-200 active:scale-95"
              >
                0
              </Button>
              <Button
                onClick={handleBackspace}
                disabled={isLoading || pin.length === 0}
                className="w-16 h-16 rounded-full bg-white dark:bg-[#2C2C2E] text-xl font-medium text-gray-800 dark:text-white shadow-sm hover:shadow-md transition-all duration-200 active:scale-95"
              >
                <Delete className="h-5 w-5" />
              </Button>
            </div>
            
            <Button
              onClick={() => setShowRecovery(true)}
              variant="ghost"
              className="text-sm text-[#FF9500] hover:text-[#e6860a]"
            >
              Forgot PIN? Recover it
            </Button>
          </>
        )}
        
        {/* Connection Status & Loading */}
        <div className="mt-4 flex items-center justify-center gap-2">
          {isLoading && (
            <div className="text-sm text-gray-600 dark:text-gray-400">
              Setting up your PIN...
            </div>
          )}
          
          {!isLoading && (
            <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
              {syncManager.isOnline() ? (
                <>
                  <Wifi className="h-3 w-3 text-green-500" />
                  <span>Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="h-3 w-3 text-orange-500" />
                  <span>Offline</span>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
