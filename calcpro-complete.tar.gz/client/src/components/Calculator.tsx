import { useState } from "react";
import { Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/hooks/useTheme";
import { useCalculator } from "@/hooks/useCalculator";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CalculatorProps {
  onSecretAccess: (userId: number, pin: string) => void;
  onSetupNewPin?: () => void;
}

export function Calculator({ onSecretAccess, onSetupNewPin }: CalculatorProps) {
  const { theme, toggleTheme } = useTheme();
  const { display, handleNumberClick, handleOperationClick, handleClear, handleEquals, handleDecimal, handleToggleSign, handlePercentage } = useCalculator();
  const { toast } = useToast();
  const [secretSequence, setSecretSequence] = useState("");

  const handleButtonClick = async (value: string, type: "number" | "operation" | "action") => {
    if (type === "number") {
      handleNumberClick(value);
      
      // Track secret sequence
      const newSequence = (secretSequence + value).slice(-4);
      setSecretSequence(newSequence);
    } else if (type === "operation") {
      handleOperationClick(value);
      setSecretSequence(""); // Reset sequence on operation
    } else if (type === "action") {
      switch (value) {
        case "clear":
          handleClear();
          setSecretSequence("");
          break;
        case "equals":
          // Check for secret sequence when equals is pressed
          if (secretSequence.length === 4) {
            // Check local storage first for fast access
            const savedPin = localStorage.getItem(`calcpro_user_${secretSequence}`);
            if (savedPin) {
              const userData = JSON.parse(savedPin);
              onSecretAccess(userData.id, userData.pin);
              setSecretSequence("");
              return;
            }
            
            // If not in local storage, check server
            try {
              const response = await apiRequest("POST", "/api/auth", { pin: secretSequence });
              const user = await response.json();
              
              // Save to local storage for next time
              localStorage.setItem(`calcpro_user_${secretSequence}`, JSON.stringify(user));
              
              onSecretAccess(user.id, user.pin);
              setSecretSequence("");
              return; // Don't execute normal equals operation
            } catch (error) {
              // Reset sequence for invalid PIN and continue with normal equals
              setSecretSequence("");
            }
          }
          handleEquals();
          setSecretSequence("");
          break;
        case "decimal":
          handleDecimal();
          break;
        case "toggle-sign":
          handleToggleSign();
          break;
        case "percentage":
          handlePercentage();
          break;
      }
    }
  };

  const buttons = [
    { label: "C", value: "clear", type: "action" as const, className: "bg-gray-200 dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "±", value: "toggle-sign", type: "action" as const, className: "bg-gray-200 dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "%", value: "percentage", type: "action" as const, className: "bg-gray-200 dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "÷", value: "divide", type: "operation" as const, className: "bg-[#FF9500] text-white" },
    
    { label: "7", value: "7", type: "number" as const, className: "bg-white dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "8", value: "8", type: "number" as const, className: "bg-white dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "9", value: "9", type: "number" as const, className: "bg-white dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "×", value: "multiply", type: "operation" as const, className: "bg-[#FF9500] text-white" },
    
    { label: "4", value: "4", type: "number" as const, className: "bg-white dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "5", value: "5", type: "number" as const, className: "bg-white dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "6", value: "6", type: "number" as const, className: "bg-white dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "−", value: "subtract", type: "operation" as const, className: "bg-[#FF9500] text-white" },
    
    { label: "1", value: "1", type: "number" as const, className: "bg-white dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "2", value: "2", type: "number" as const, className: "bg-white dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "3", value: "3", type: "number" as const, className: "bg-white dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "+", value: "add", type: "operation" as const, className: "bg-[#FF9500] text-white" },
    
    { label: "0", value: "0", type: "number" as const, className: "bg-white dark:bg-[#2C2C2E] text-gray-800 dark:text-white col-span-2" },
    { label: ".", value: "decimal", type: "action" as const, className: "bg-white dark:bg-[#2C2C2E] text-gray-800 dark:text-white" },
    { label: "=", value: "equals", type: "action" as const, className: "bg-[#FF9500] text-white" },
  ];

  return (
    <div className="px-6 pb-8 flex-1 pt-16">
      {/* Header */}
      <div className="flex justify-center items-center mb-6 relative">
        <h1 className="text-2xl font-light text-gray-800 dark:text-white">CalcPro</h1>
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleTheme}
          className="absolute right-0 p-2 rounded-lg bg-white dark:bg-[#2C2C2E] text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>

      {/* Display */}
      <div className="mb-5">
        <div className="bg-white dark:bg-[#3A3A3C] rounded-2xl p-5 shadow-sm">
          <div className="text-right text-4xl font-light text-gray-800 dark:text-white min-h-[50px] flex items-center justify-end">
            {display}
          </div>
        </div>
      </div>

      {/* Calculator Buttons */}
      <div className="grid grid-cols-4 gap-3">
        {buttons.map((button, index) => (
          <Button
            key={index}
            onClick={() => handleButtonClick(button.value, button.type)}
            className={`h-16 rounded-xl text-xl font-light shadow-sm hover:shadow-md transition-all duration-200 active:scale-95 ${button.className} ${button.label === "0" ? "col-span-2" : ""}`}
          >
            {button.label}
          </Button>
        ))}
      </div>
      
      {/* Setup New PIN Button */}
      {onSetupNewPin && (
        <div className="mt-4">
          <Button
            onClick={onSetupNewPin}
            variant="outline"
            className="w-full text-sm !text-black dark:!text-[#FF9500] !border-black dark:!border-[#FF9500] hover:!bg-black dark:hover:!bg-[#FF9500] hover:!text-white"
          >
            Setup New PIN
          </Button>
        </div>
      )}
    </div>
  );
}
