import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertFileSchema, insertSettingsSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByPin(userData.pin);
      
      if (existingUser) {
        return res.status(400).json({ message: "PIN already exists" });
      }
      
      const user = await storage.createUser(userData);
      
      // Create default settings for new user
      await storage.createSettings({
        userId: user.id,
        theme: "light",
        language: "en",
        isPremium: false,
      });
      
      res.json(user);
    } catch (error: any) {
      if (error.message === "PIN_ALREADY_EXISTS") {
        res.status(409).json({ message: "PIN_ALREADY_EXISTS" });
      } else {
        res.status(400).json({ message: error.message || "Invalid user data" });
      }
    }
  });

  app.post("/api/auth", async (req, res) => {
    try {
      const { pin } = req.body;
      if (!pin || pin.length !== 4) {
        return res.status(400).json({ message: "Invalid PIN format" });
      }
      
      const user = await storage.getUserByPin(pin);
      if (!user) {
        return res.status(401).json({ message: "Invalid PIN" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Authentication failed" });
    }
  });

  app.post("/api/recover-pin", async (req, res) => {
    try {
      const { securityAnswer } = req.body;
      if (!securityAnswer) {
        return res.status(400).json({ message: "Security answer is required" });
      }
      
      const user = await storage.getUserBySecurityAnswer(securityAnswer);
      if (!user) {
        return res.status(404).json({ message: "Security answer not found" });
      }
      
      res.json({ pin: user.pin });
    } catch (error) {
      res.status(400).json({ message: "PIN recovery failed" });
    }
  });

  // File routes
  app.get("/api/files", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      const files = await storage.getFilesByUserId(parseInt(userId));
      res.json(files);
    } catch (error) {
      res.status(400).json({ message: "Failed to fetch files" });
    }
  });

  app.post("/api/files", async (req, res) => {
    try {
      const fileData = insertFileSchema.parse(req.body);
      const file = await storage.createFile(fileData);
      res.json(file);
    } catch (error) {
      res.status(400).json({ message: "Invalid file data" });
    }
  });

  app.delete("/api/files/:id", async (req, res) => {
    try {
      const fileId = parseInt(req.params.id);
      const { userId } = req.body;
      
      const success = await storage.deleteFile(fileId, userId);
      if (success) {
        res.json({ message: "File deleted successfully" });
      } else {
        res.status(404).json({ message: "File not found or unauthorized" });
      }
    } catch (error) {
      res.status(400).json({ message: "Failed to delete file" });
    }
  });

  // Settings routes
  app.get("/api/settings/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const settings = await storage.getSettingsByUserId(userId);
      if (!settings) {
        return res.status(404).json({ message: "Settings not found" });
      }
      res.json(settings);
    } catch (error) {
      res.status(400).json({ message: "Failed to fetch settings" });
    }
  });

  app.patch("/api/settings/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const updateData = req.body;
      
      const settings = await storage.updateSettings(userId, updateData);
      if (!settings) {
        return res.status(404).json({ message: "Settings not found" });
      }
      
      res.json(settings);
    } catch (error) {
      res.status(400).json({ message: "Failed to update settings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
