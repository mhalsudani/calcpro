import { users, files, settings, type User, type InsertUser, type File, type InsertFile, type Settings, type InsertSettings } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User operations
  createUser(user: InsertUser): Promise<User>;
  getUserByPin(pin: string): Promise<User | undefined>;
  getUserBySecurityAnswer(securityAnswer: string): Promise<User | undefined>;
  
  // File operations
  createFile(file: InsertFile): Promise<File>;
  getFilesByUserId(userId: number): Promise<File[]>;
  deleteFile(id: number, userId: number): Promise<boolean>;
  
  // Settings operations
  createSettings(settings: InsertSettings): Promise<Settings>;
  getSettingsByUserId(userId: number): Promise<Settings | undefined>;
  updateSettings(userId: number, settings: Partial<InsertSettings>): Promise<Settings | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByPin(pin: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.pin, pin));
    return user || undefined;
  }

  async getUserBySecurityAnswer(securityAnswer: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.securityAnswer, securityAnswer));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Check if PIN already exists
    const existingUser = await this.getUserByPin(insertUser.pin);
    if (existingUser) {
      throw new Error("PIN_ALREADY_EXISTS");
    }
    
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createFile(insertFile: InsertFile): Promise<File> {
    const [file] = await db
      .insert(files)
      .values(insertFile)
      .returning();
    return file;
  }

  async getFilesByUserId(userId: number): Promise<File[]> {
    return await db.select().from(files).where(eq(files.userId, userId));
  }

  async deleteFile(id: number, userId: number): Promise<boolean> {
    const result = await db
      .delete(files)
      .where(eq(files.id, id))
      .returning();
    
    return result.length > 0 && result[0].userId === userId;
  }

  async createSettings(insertSettings: InsertSettings): Promise<Settings> {
    const [setting] = await db
      .insert(settings)
      .values({
        userId: insertSettings.userId,
        theme: insertSettings.theme || "light",
        language: insertSettings.language || "en",
        isPremium: insertSettings.isPremium || false
      })
      .returning();
    return setting;
  }

  async getSettingsByUserId(userId: number): Promise<Settings | undefined> {
    const [setting] = await db.select().from(settings).where(eq(settings.userId, userId));
    return setting || undefined;
  }

  async updateSettings(userId: number, updateData: Partial<InsertSettings>): Promise<Settings | undefined> {
    const [setting] = await db
      .update(settings)
      .set(updateData)
      .where(eq(settings.userId, userId))
      .returning();
    return setting || undefined;
  }
}

export const storage = new DatabaseStorage();
